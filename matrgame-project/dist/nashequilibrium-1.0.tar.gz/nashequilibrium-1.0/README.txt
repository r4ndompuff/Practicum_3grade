DESCRIPTION
===========
This library finds optimal strategies for players A and B in matrix game
